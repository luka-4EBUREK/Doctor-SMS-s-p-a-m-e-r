# Duplo Bomber
Private SMS-Bomber (for Ukraine phone numbers)
# Install
- apt update && apt upgrade
- pkg install python
- apt install git
- git clone https://github.com/batiscuff/duplo-bomber
- cd duplo-bomber
- pip3 install -r requirements.txt
# Start
python3 duplo_spam.py
# License
Mozilla Public License 2.0
